var cotacaoDoDia=prompt("Insira a cotação do dia:");
var valorDoProduto=prompt("Insira o valor do seu produto no Exterior");
var valorNoBrasil=prompt("Insira o valor do seu produto no Brasil");
var cotado=Number(cotacaoDoDia)*Number(valorDoProduto);
var custoBrasil=Number(valorNoBrasil)-Number(valorDoProduto);
alert("O valor do seu produto no exterior, ém Reais,  é R$"+cotado.toFixed(2));
alert("O Custo Brasil desse produto é de R$"+custoBrasil.toFixed(2));

