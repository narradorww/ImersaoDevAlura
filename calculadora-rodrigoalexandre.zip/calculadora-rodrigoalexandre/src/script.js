var operador =parseInt(prompt("Insira o primeiro valor"));
var operando =parseInt(prompt("Insira o segundo valor"));
var operacao= prompt("Insira Operação");
var resultado;

if (operacao === "+"){
    resultado=operador+operando;//Realiza soma do termo
    document.write("<h2>"+operador +"+"+ operando +"="+ resultado + "</h2>");
} else if (operacao==="-") {
  resultado=operador-operando; //Realiza subtração do termo
    document.write("<h2>"+operador +"-"+ operando +"="+ resultado + "</h2>");
} else if (operacao=="*") {
  resultado=operador*operando;//Realiza o produto dos termos
    document.write("<h2>"+operador +"*"+ operando +"="+ resultado + "</h2>"); 
}else if (operacao==="/") {
  resultado=operador/operando;//Realiza operação de divisão
    document.write("<h2>"+operador +"/"+ operando +"="+ resultado + "</h2>");
}  else if (operacao==="**") {
  resultado=operador**operando;//Realiza operação de potencia
    document.write("<h2>"+operador +"^"+ operando +"="+ resultado + "</h2>");
} else document.write("<h2>Não Trabalhamos</h2>");
